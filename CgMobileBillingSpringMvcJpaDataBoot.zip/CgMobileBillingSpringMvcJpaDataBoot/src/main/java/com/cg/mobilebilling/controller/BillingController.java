package com.cg.mobilebilling.controller;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class BillingController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/viewPlan")
	public ModelAndView getViewPlan() throws BillingServicesDownException {
		List<Plan> plans=billingServices.getPlanAllDetails();
		return new ModelAndView("planDetailsPage","plans",plans);
	}
	@RequestMapping("/displayRegistration")
	public ModelAndView getdisplayRegistration(@Valid@ModelAttribute Customer customer,BindingResult bindingResult){
		if(bindingResult.hasErrors())
			return new ModelAndView("RegistrationPage");
		int customerID=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("RegisterationSuccessPage","customerID",customerID);
	}
	@RequestMapping("/displayPostpaidAccountPage")
	public ModelAndView getdisplayPostpaidAccountPage(@RequestParam("customerID")int customerID,@RequestParam("planID")int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException{
		long mobileNo=billingServices.openPostpaidMobileAccount(customerID, planID);
		return new ModelAndView("PostpaidAccountSuccessPage","mobileNo",mobileNo);
	}
	@RequestMapping("/MonthlyMobileBillingpage")
	public ModelAndView getMonthlyMobileBillingpage(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo,
			@RequestParam("billMonth")String billMonth,@RequestParam("noOfLocalSMS")int noOfLocalSMS,
			@RequestParam("noOfStdSMS")int noOfStdSMS,
			@RequestParam("noOfLocalCalls")int noOfLocalCalls,@RequestParam("noOfStdCalls")int noOfStdCalls,
			@RequestParam("internetDataUsageUnits")int internetDataUsageUnits) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillingServicesDownException, PlanDetailsNotFoundException{
		int totalBillAmount=billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
		return new ModelAndView("MonthlyBillAmountPage","totalBillAmount",totalBillAmount);
	}
}

package com.cg.mobilebilling.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.PostpaidAccount;
@Controller
public class URIController {
	Customer customer;
	PostpaidAccount postpaidAccount;
	Bill bill;
	@RequestMapping("/")
	public String getIndexpage() {
		return "indexPage";
	}
	@RequestMapping("/registerCustomer")
	public String getRegisterCustomer() {
		return "RegistrationPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}
	@RequestMapping("/openPostpaidMobileAccount")
	public String getPostpaidAccountPage() {
		return "PostpaidAccountPage";
	}
	@ModelAttribute
	public PostpaidAccount getPostpaidAccount() {
		postpaidAccount= new PostpaidAccount();
		return postpaidAccount;
	}
	@RequestMapping("/generateMonthlyMobileBill")
	public String getMonthlyMobileBill() {
		return "MonthlyMobileBillPage";
	}
	@ModelAttribute
	public Bill getBill() {
		bill= new Bill();
		return bill;
	}
}

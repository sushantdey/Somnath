package com.cg.mobilebilling.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;

import oracle.net.aso.b;
@Component("BillingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private PlanDAOServices planDAOServices;
	@Autowired
	private CustomerDAOServices customerDAOServices;
	@Autowired
	private BillingDAOServices billingDAOServices;
	@Autowired
	private PostpaidAccountDAOServices postpaidAccountDAOServices;
	Plan plan;
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		Plan plan= new Plan(150, 100, 100, 100, 100, 1024, 1, 2, 1, 5, 5, "Maharastra-Goa", "Silver Pack");
		planDAOServices.save(plan);
		List<Plan> list= (List<Plan>) planDAOServices.findAll();
		return list;
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailID, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode)
			throws BillingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOServices.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details are not present"));
		Plan plan=planDAOServices.findById(planID).orElseThrow(()-> new PlanDetailsNotFoundException("Plan don't exist"));
		PostpaidAccount postpaidAccount= new PostpaidAccount(customer, plan);
		postpaidAccountDAOServices.save(postpaidAccount);
		return postpaidAccount.getMobileNo();
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		Customer customer = customerDAOServices.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found"));
		PostpaidAccount postpaidAccount=postpaidAccountDAOServices.findById((int) mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("PostpaidAccount not found"));
		if(noOfLocalCalls>plan.getFreeLocalCalls())
			noOfLocalCalls-=plan.getFreeLocalCalls();
		else
			noOfLocalCalls=0;
		if(noOfLocalSMS>plan.getFreeLocalSMS())
			noOfLocalSMS-=plan.getFreeLocalSMS();
		else
			noOfLocalSMS=0;
		if(noOfStdSMS>plan.getFreeStdSMS())
			noOfStdSMS-=plan.getFreeStdSMS();
		else
			noOfStdSMS=0;
		if(noOfStdCalls>plan.getFreeStdCalls())
			noOfStdCalls-=plan.getFreeStdCalls();
		else
			noOfStdCalls=0;
		if(internetDataUsageUnits>plan.getFreeInternetDataUsageUnits())
			internetDataUsageUnits-=plan.getFreeInternetDataUsageUnits();
		else
			internetDataUsageUnits=0;
		float localCallAmount= noOfLocalCalls*plan.getLocalCallRate();
		float localSMSAmount=noOfLocalSMS*plan.getLocalSMSRate();
		float stdCallAmount=noOfStdCalls*plan.getStdCallRate();
		float stdSMSAmount=noOfStdSMS*plan.getStdSMSRate();
		float internetDataUsageAmount=internetDataUsageUnits*plan.getInternetDataUsageRate();
		float billAmount=localCallAmount+localSMSAmount+stdCallAmount+stdSMSAmount+internetDataUsageAmount;
		float serviceTax=(billAmount+(billAmount*6))/100;
		float vat=(billAmount+(billAmount*5))/100;
		int totalBillAmount=(int) (billAmount+serviceTax+vat);
		return totalBillAmount;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int acceptCustomerDetails(Customer customer) {
		customerDAOServices.save(customer);
		return customer.getCustomerID();
	}

	@Override
	public long openPostpaidMobileAccount(PostpaidAccount postpaidAccount) {
		postpaidAccountDAOServices.save(postpaidAccount);
		return postpaidAccount.getMobileNo();
	}

	@Override
	public int generateMonthlyMobileBill(Bill bill) {
		billingDAOServices.save(bill);
		return (int) bill.getTotalBillAmount();
	}



}
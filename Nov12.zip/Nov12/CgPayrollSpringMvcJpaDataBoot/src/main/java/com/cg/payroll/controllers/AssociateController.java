package com.cg.payroll.controllers;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;
@Controller
public class AssociateController {
	@Autowired
	private PayrollServices payrollServices;
	Associate associate;
	@RequestMapping("/registerAssociate")
	public ModelAndView registerAssociateAction(@Valid@ModelAttribute Associate associate,BindingResult bindingResult) {
		if(bindingResult.hasErrors())
			return new ModelAndView("registerPage");
		associate=payrollServices.acceptAssociateDetails(associate);
		return new ModelAndView("registrationSuccessPage", "associate", associate);
	}
	@RequestMapping("/CalculateNetSalary")
	public ModelAndView calculateNetSalary(@RequestParam("associateId")int associateId){
		int netSalary=payrollServices.calculateNetSalary(associateId);
		return new ModelAndView("displayNetSalary", "netSalary", netSalary);
	}
	@RequestMapping("/AssociateDetails")
	public ModelAndView getAssociateDeatils(@RequestParam("associateId")int associateId){
		associate=payrollServices.getAssociateDetails(associateId);
		return new ModelAndView("displayAssociateDetailsPage", "associate", associate);
	}
	@RequestMapping("/AllAssociateDetails")
	public ModelAndView getAllAssociateDeatils(){
		ArrayList<Associate> associates=payrollServices.getAllAsociateDetails();
		return new ModelAndView("displayAllAssociateDetailsPage", "associates", associates);
	}
}
package com.cg.mobilebilling.controllers;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class BillingController {
	@Autowired
	private BillingServices billingServices;
	Customer customer;
	PostpaidAccount postpaidAccount;
	Bill bill;
	Plan plan;
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid@ModelAttribute Customer customer,BindingResult bindingResultCustomer) throws BillingServicesDownException {
		if(bindingResultCustomer.hasErrors())
			return new ModelAndView("registerPage");
		int customerID=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("registrationSuccessPage", "customerID", customerID);
	}
	@RequestMapping("/allPlanDetails")
	public ModelAndView returnAllPlanDetails() throws BillingServicesDownException {
		List<Plan> plans = billingServices.getPlanAllDetails();
		return new ModelAndView("displayAllPlanDetailsPage", "plans", plans);
	}
	@RequestMapping("/OpenPostpaidMobileAccount")
	public ModelAndView openPostpaidMobileAccount(@RequestParam("customerID")int customerID,@RequestParam("planID")int planID) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		long mobileNo=billingServices.openPostpaidMobileAccount(customerID, planID);
		return new ModelAndView("accountOpeningSuccessPage", "mobileNo", mobileNo);
	}
	@RequestMapping("/GenerateMonthlyMobileBill")
	public ModelAndView generateMonthlyMobileBill(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo,
			@RequestParam("billMonth")String billMonth,@RequestParam("noOfLocalSMS")int noOfLocalSMS,
			@RequestParam("noOfStdSMS")int noOfStdSMS,
			@RequestParam("noOfLocalCalls")int noOfLocalCalls,@RequestParam("noOfStdCalls")int noOfStdCalls,
			@RequestParam("internetDataUsageUnits")int internetDataUsageUnits)
					throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {
		int totalBillAmount = billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
		return new ModelAndView("displayMonthlyMobileBillPage", "totalBillAmount", totalBillAmount);
	}
	@RequestMapping("/displayCustomer")
	public ModelAndView getCustomerDetails(@RequestParam("customerID")int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException {
		customer=billingServices.getCustomerDetails(customerID);
		System.out.println(customer.toString());
		return new ModelAndView("displayCustomerDetailsPage", "customer", customer);
	}
	@RequestMapping("/allCustomerDetails")
	public ModelAndView getAllCustomerDetails() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		List<Customer> customers =billingServices.getAllCustomerDetails();
		System.out.println(customers.toString());
		return new ModelAndView("displayAllCustomerDetailsPage", "customers", customers);
	}
	@RequestMapping("/displayPostPaidAccountDetails")
	public ModelAndView getPostPaidAccountDetails(@RequestParam("customerID")int customerID, @RequestParam("mobileNo")long mobileNo) throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		postpaidAccount=billingServices.getPostPaidAccountDetails(customerID, mobileNo);
		return new ModelAndView("displayPostPaidAccountDetailsPage", "postpaidAccount", postpaidAccount);
	}
	@RequestMapping("/displayCustomerAllPostpaidAccountsDetails")
	public ModelAndView getDisplayCustomerAllPostpaidAccountsDetails(@RequestParam("customerID")int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		List<PostpaidAccount> postpaidAccounts=billingServices.getCustomerAllPostpaidAccountsDetails(customerID);
		return new ModelAndView("displayCustomerAllPostpaidAccountsDetailsPage", "postpaidAccounts", postpaidAccounts);
	}
	@RequestMapping("/displayMonthlyBill")
	public ModelAndView getDisplayMonthlyBill(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo,@RequestParam("billMonth")String billMonth) throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		Bill bill=billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
		return new ModelAndView("displayMonthlyBillPage", "bill", bill);
	}
	@RequestMapping("/displayCustomerPostPaidAccountAllBillDetails")
	public ModelAndView getDisplayCustomerPostPaidAccountAllBillDetails(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		List<Bill> bills=billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
		return new ModelAndView("displayMonthlyBillPage", "bills", bills);
	}
	@RequestMapping("/ChangePlan")
	public ModelAndView getChangePlan(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo,@RequestParam("planID")int planID) throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, PlanDetailsNotFoundException {
		billingServices.changePlan(customerID, mobileNo, planID);
		return new ModelAndView("getChangePlanPage", "successMessage", "Your Plan has been changed Successfully");
	}
	@RequestMapping("/DeletePostpaidAccount")
	public ModelAndView getDeletePostpaidAccount(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, PlanDetailsNotFoundException {
		billingServices.closeCustomerPostPaidAccount(customerID, mobileNo);
		return new ModelAndView("getDeletePostpaidAccountPage", "successMessage", "Your Account has been closed Successfully");
	}
	@RequestMapping("/DeleteCustomer")
	public ModelAndView getDeleteCustomer(@RequestParam("customerID")int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, PlanDetailsNotFoundException {
		billingServices.deleteCustomer(customerID);
		return new ModelAndView("getDeleteCustomerPage", "successMessage", "Your Account has been closed Successfully");
	}
	@RequestMapping("/CustomerPostPaidAccountPlanDetailsPage")
	public ModelAndView getCustomerPostPaidAccountPlanDetails(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, PlanDetailsNotFoundException {
		Plan plan=billingServices.getCustomerPostPaidAccountPlanDetails(customerID,mobileNo);
		return new ModelAndView("displayCustomerPostPaidAccountPlanDetailsPage", "plan",plan);
	}
}
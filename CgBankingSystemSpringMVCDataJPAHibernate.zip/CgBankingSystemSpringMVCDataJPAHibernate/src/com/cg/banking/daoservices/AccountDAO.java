package com.cg.banking.daoservices;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.banking.beans.Account;
public interface AccountDAO extends JpaRepository<Account, Long> {
/*	Account save(Account account) ;
	Account findOne(long accountNo);
	ArrayList<Account> findAll() ;
	ArrayList<Transaction>findAccountAllTransactions(long accountNo) ;
	Transaction save(Transaction transaction);
	boolean updateAccount(Account account);*/
/*	@Query("getAllAccountDetails")
	List<Account> getAllAccountDetails();*/
}
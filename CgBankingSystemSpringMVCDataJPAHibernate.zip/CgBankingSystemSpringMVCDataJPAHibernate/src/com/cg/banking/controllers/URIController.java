package com.cg.banking.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;
@Controller
public class URIController {
	Account account;
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/openAccount")
	public String openAccountPage() {
		return "openAccountPage";
	}
	@ModelAttribute
	public Account getAccount() {
		account=new Account();
		return account;
	}
	@RequestMapping("/depositPage")
	public String depositAmount() {
		return "accountNoDepositPage";
	}
	@RequestMapping("/withdrawPage")
	public String withdrawAmount() {
		return "accountNoWithdrawPage";
	}
	@RequestMapping("/fundTransfer")
	public String fundTransfer() {
		return "fundTransferPage";
	}
	@RequestMapping("/accountDetails")
	public String accountDetails() {
		return "accountNoAccountDetails";
	}
	
}
